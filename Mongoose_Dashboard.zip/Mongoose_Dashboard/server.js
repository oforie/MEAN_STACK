
// require express
var express = require("express");
// path module -- try to figure out where and why we use this
var path = require("path");
// create the express app
var app = express();
var bodyParser = require('body-parser');

var session = require('express-session');
app.use(session({secret: 'codingdojorocks'}))

var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/animal_library');
// use it!
app.use(bodyParser.urlencoded({ extended: true }));
// static content
app.use(express.static(path.join(__dirname, "./static")));
// setting up ejs and our views folder
app.set('views', path.join(__dirname, './views'));
app.set('view engine', 'ejs');

mongoose.Promise = global.Promise;


var AnimalSchema = new mongoose.Schema({
    name: {type:String, required: true, minlength: 2},
    color: {type:String, required: true,minlength: 2 },
    description: {type: String, required: true, minlength:5, maxlength:200}}, {timestamps:true}
);

mongoose.model('Animal', AnimalSchema);
var Animal = mongoose.model('Animal');

// shows all mongooses ie: db query here
app.get('/', function(req, res) {
      Animal.find({}, function(err, animals){
         if(err){
            console.log('******errror at index line 39****')
            res.render('index', {title:'fix this before moving on', errors:animals.errors})
        } else {
            res.render('index', {animals:animals});   
        }
    })
})
      
// post route to process adding a mongoose
app.post('/mongooses', function(req, res) {
 console.log("POST DATA", req.body);
 var animal = new Animal({name:req.body.name, color:req.body.color, description:req.body.description})
 animal.save(function(err){
     if(err){
        console.log('something is not right', err);
        res.render('addform', {title:'attend to these errors', errors:animal.errors});
     } else {
         res.redirect('index');
     }
 })
})


app.get('/mongooses/new', function(req, res) {
 res.render("addform");
})

app.get('/selfies', function(req, res) {
 res.render("selfies");
})

// displaying individual animals
app.get('/mongooses/:id', function(req, res) {
    Animal.find({_id:(req.params.id)}, function(err, animals){
         if(err){
            res.render('selfies', {errors:animals.errors});
        } else {
            res.render('selfies', {animals:animals});  
           
        }
    })
})

// route for editing animal:
app.get('/mongooses/edit/:id', function(req, res) {
    Animal.findOne({_id:(req.params.id)}, function(err, animals){
        console.log(req.params.id, '*****line 85****');
         if(err){
            console.log('****error on line 86');
            res.render('animal_edit', {errors:animals.errors})
        } else {
            res.render('animal_edit', {animals:animals});   
        }
    })
})

// modifying entry: not catching the id
app.post('/mongooses/edit/:id', function(req, res) {
    Animal.findOne({_id:(req.params.id)}, function(err, animals){
        console.log(req.params.id, "*******line 98***");
         if(err){
            res.render('selfies', {errors:animals.errors});
        } else {
            animals.name = req.body.name;
            animals.color = req.body.color;
            animals.description = req.body.description;
            animals.save();
            console.log('update saved')
            res.render('selfies', {animals:animals});  
        }
    })
})

// post route to process adding a mongoose
app.post('/mongooses', function(req, res) {
    count++;
    given_id = count;
    console.log("POST DATA", req.body);
    var animal = new Animal({name:req.body.name, color:req.body.color, description:req.body.description})
    animal.save(function(err){
     if(err){
        console.log('something is not right');
        res.render('addform', {title:'attend to these errors', errors:animal.errors});
     } else {
         res.redirect('index');
     }
 })
})



// tell the express app to listen on port 8000
app.listen(8000, function() {
 console.log("listening on port 8000");
});
